<!DOCTYPE html>
<html>
<head>
    <title>Admin Home - Hotel Management</title>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7fa;
            margin: 0;
            padding: 0;
        }
        header {
            background: #2c3e50;
            color: #fff;
            padding: 15px;
            text-align: center;
        }
    </style>
</head>
<body>
	<header>
		<h1>DH HOTEL</h1>
		<p>WELCOME ADMIN !</p>
	</header>
</body>
</html>

