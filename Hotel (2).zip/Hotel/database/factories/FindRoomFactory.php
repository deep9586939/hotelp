<?php

$factory->define(App\FindRoom::class, function (Faker\Generator $faker) {
    return [

    ];
});
